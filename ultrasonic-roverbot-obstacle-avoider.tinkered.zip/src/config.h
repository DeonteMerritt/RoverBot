#pragma once

#include <Arduino.h>

// Pin map (must match wiring exactly)
static const uint8_t SWITCH_PIN = 2;

static const uint8_t ENA_PIN = 3;  // L298N ENA (PWM)
static const uint8_t IN1_PIN = 4;  // L298N IN1
static const uint8_t ENB_PIN = 5;  // L298N ENB (PWM)
static const uint8_t IN2_PIN = 7;  // L298N IN2
static const uint8_t IN3_PIN = 8;  // L298N IN3
static const uint8_t IN4_PIN = 9;  // L298N IN4

static const uint8_t TRIG_PIN = 10; // HC-SR04 TRIG
static const uint8_t ECHO_PIN = 11; // HC-SR04 ECHO

static const uint8_t EYE_LEFT_PIN = 12;
static const uint8_t EYE_RIGHT_PIN = 13;
static const uint8_t MOUTH_PIN = A0;

// Behavior tuning
static const uint8_t CRUISE_SPEED = 200;          // 0..255
static const uint8_t BACKUP_SPEED = 180;          // 0..255
static const uint8_t TURN_SPEED = 180;            // 0..255
static const uint16_t OBSTACLE_CM = 20;           // obstacle threshold
static const uint16_t SENSOR_INTERVAL_MS = 70;    // HC-SR04 >= 60ms
static const uint16_t STOP_BEFORE_BACK_MS = 180;
static const uint16_t BACKUP_MS = 450;
static const uint16_t TURN_MS = 420;
static const uint16_t MOUTH_BLINK_MS = 120;
