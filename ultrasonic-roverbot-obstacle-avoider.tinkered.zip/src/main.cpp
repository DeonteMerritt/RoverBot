#include <Arduino.h>
#include "config.h"

// INPUT_PULLUP active-low switch: ON/closed-to-GND reads LOW.
static inline bool isRobotActive() {
  return digitalRead(SWITCH_PIN) == LOW;
}

void setFace(bool eyesOn, bool mouthOn) {
  digitalWrite(EYE_LEFT_PIN, eyesOn ? HIGH : LOW);
  digitalWrite(EYE_RIGHT_PIN, eyesOn ? HIGH : LOW);
  digitalWrite(MOUTH_PIN, mouthOn ? HIGH : LOW);
}

void driveMotorA(int16_t speed) {
  speed = constrain(speed, -255, 255);

  if (speed > 0) {
    digitalWrite(IN1_PIN, HIGH);
    digitalWrite(IN2_PIN, LOW);
    analogWrite(ENA_PIN, speed);
  } else if (speed < 0) {
    digitalWrite(IN1_PIN, LOW);
    digitalWrite(IN2_PIN, HIGH);
    analogWrite(ENA_PIN, -speed);
  } else {
    digitalWrite(IN1_PIN, LOW);
    digitalWrite(IN2_PIN, LOW);
    analogWrite(ENA_PIN, 0);
  }
}

void driveMotorB(int16_t speed) {
  speed = constrain(speed, -255, 255);

  if (speed > 0) {
    digitalWrite(IN3_PIN, HIGH);
    digitalWrite(IN4_PIN, LOW);
    analogWrite(ENB_PIN, speed);
  } else if (speed < 0) {
    digitalWrite(IN3_PIN, LOW);
    digitalWrite(IN4_PIN, HIGH);
    analogWrite(ENB_PIN, -speed);
  } else {
    digitalWrite(IN3_PIN, LOW);
    digitalWrite(IN4_PIN, LOW);
    analogWrite(ENB_PIN, 0);
  }
}

void stopDrive() {
  driveMotorA(0);
  driveMotorB(0);
}

void driveForward(uint8_t speed) {
  driveMotorA(speed);
  driveMotorB(speed);
}

void driveBackward(uint8_t speed) {
  driveMotorA(-speed);
  driveMotorB(-speed);
}

void turnInPlace(uint8_t speed) {
  // Left reverse, right forward (pivot turn)
  driveMotorA(-speed);
  driveMotorB(speed);
}

uint16_t readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Timeout ~30ms (~5m max range)
  unsigned long durationUs = pulseIn(ECHO_PIN, HIGH, 30000UL);
  if (durationUs == 0) {
    return 999; // no echo
  }

  return static_cast<uint16_t>(durationUs * 0.0343f / 2.0f);
}

bool runTimedMotionWithMouthBlink(uint16_t durationMs, int16_t speedA, int16_t speedB) {
  unsigned long start = millis();
  unsigned long lastBlink = millis();
  bool mouthState = false;

  driveMotorA(speedA);
  driveMotorB(speedB);

  while (millis() - start < durationMs) {
    if (!isRobotActive()) {
      stopDrive();
      setFace(false, false);
      return false;
    }

    if (millis() - lastBlink >= MOUTH_BLINK_MS) {
      mouthState = !mouthState;
      digitalWrite(MOUTH_PIN, mouthState ? HIGH : LOW);
      lastBlink = millis();
    }
  }

  digitalWrite(MOUTH_PIN, LOW);
  return true;
}

void obstacleAvoidManeuver() {
  stopDrive();
  digitalWrite(MOUTH_PIN, HIGH);
  delay(STOP_BEFORE_BACK_MS);

  if (!isRobotActive()) {
    stopDrive();
    setFace(false, false);
    return;
  }

  if (!runTimedMotionWithMouthBlink(BACKUP_MS, -BACKUP_SPEED, -BACKUP_SPEED)) {
    return;
  }

  if (!runTimedMotionWithMouthBlink(TURN_MS, -TURN_SPEED, TURN_SPEED)) {
    return;
  }

  digitalWrite(MOUTH_PIN, LOW);
}

void setup() {
  pinMode(SWITCH_PIN, INPUT_PULLUP);

  pinMode(ENA_PIN, OUTPUT);
  pinMode(IN1_PIN, OUTPUT);
  pinMode(ENB_PIN, OUTPUT);
  pinMode(IN2_PIN, OUTPUT);
  pinMode(IN3_PIN, OUTPUT);
  pinMode(IN4_PIN, OUTPUT);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(EYE_LEFT_PIN, OUTPUT);
  pinMode(EYE_RIGHT_PIN, OUTPUT);
  pinMode(MOUTH_PIN, OUTPUT);

  stopDrive();
  setFace(false, false);
}

void loop() {
  static unsigned long lastSensorReadMs = 0;

  if (!isRobotActive()) {
    stopDrive();
    setFace(false, false);
    delay(20);
    return;
  }

  // Active state face
  digitalWrite(EYE_LEFT_PIN, HIGH);
  digitalWrite(EYE_RIGHT_PIN, HIGH);
  digitalWrite(MOUTH_PIN, LOW);

  driveForward(CRUISE_SPEED);

  if (millis() - lastSensorReadMs >= SENSOR_INTERVAL_MS) {
    lastSensorReadMs = millis();
    uint16_t distanceCm = readDistanceCm();

    if (distanceCm < OBSTACLE_CM) {
      obstacleAvoidManeuver();
    }
  }
}
