# Roverbot

A beginner-friendly Arduino Uno robot with obstacle avoidance, blinky eyes, and a reactive mouth.

## What it does

This autonomous roverbot patrols an area using an ultrasonic sensor. If it detects an obstacle within 20cm, it stops, reverses, turns, and continues. It features "eyes" that light up when active and a "mouth" that blinks while moving.

## Hardware

*   **Arduino Uno** — The brain of the robot.
*   **L298N Stepper Driver** — Controls two DC motors.
*   **HC-SR04 Ultrasonic Sensor** — Detects obstacles.
*   **DC Motors** — Two motors for movement (left and right).
*   **LEDs** — Blue (eyes), Red (mouth).
*   **Slide Switch** — Toggles the robot on/off.
*   **Resistors** — 300Ω current limiters for the LEDs.
*   **Diodes** — 1N4007 protection for the motors.

## Wiring

### Power
*   **5V:** Connect Arduino 5V to L298N 5V and Breadboard power rail (positive).
*   **GND:** Connect Arduino GND to L298N GND and Breadboard power rail (negative).

### Motor Control (L298N)
*   **ENA (Speed Left):** Arduino Pin 3
*   **IN1 (Dir Left):** Arduino Pin 4
*   **IN2 (Dir Left):** Arduino Pin 7
*   **ENB (Speed Right):** Arduino Pin 5
*   **IN3 (Dir Right):** Arduino Pin 8
*   **IN4 (Dir Right):** Arduino Pin 9

### Sensors & Inputs
*   **TRIG (HC-SR04):** Arduino Pin 10
*   **ECHO (HC-SR04):** Arduino Pin 11
*   **SWITCH:** Arduino Pin 2 (Connect COM to Pin 2, A/B to GND)

### Output Indicators
*   **Eye Left:** Arduino Pin 12
*   **Eye Right:** Arduino Pin 13
*   **Mouth:** Arduino Pin A0
*   **Eye Left Resistor:** Pin 12 to Pin 34 (Breadboard)
*   **Eye Right Resistor:** Pin 13 to Pin 43 (Breadboard)
*   **Mouth Resistor:** Pin A0 to Pin 52 (Breadboard)

### Motor Connections
*   **Motor Left VCC:** L298N OUT1
*   **Motor Left GND:** L298N OUT2
*   **Motor Right VCC:** L298N OUT3
*   **Motor Right GND:** L298N OUT4
*   *Note: Diodes (1N4007) are connected in parallel with motors for protection.*

## How to use

1.  **Power:** Connect the Arduino via USB.
2.  **Activate:** Flip the slide switch to the "ON" position (COM to A or B). The eyes will turn blue.
3.  **Run:** The robot will move forward.
4.  **Obstacle:** If it hits an object (within ~20cm), it will stop, flash its mouth red, back up, turn, and continue.
5.  **Stop:** Flip the switch to "OFF" to stop the robot immediately.

## Files

*   `platformio.ini` — Project configuration for the build environment.
*   `src/config.h` — Pin definitions and speed settings.
*   `src/main.cpp` — Main logic for movement, sensor reading, and obstacle avoidance.
*   `wiring/wiring.json` — Visual schematic of the breadboard connections.
*   `schematic/main.sch` — Electrical schematic of the project.