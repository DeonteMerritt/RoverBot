{
  "version": 1,
  "symbols": [
    {
      "id": "arduino_1",
      "type": "reg:arduino-uno",
      "ref": "U1",
      "x": 55,
      "y": 120,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "drv_1",
      "type": "reg:l298n-stepper-driver",
      "ref": "U2",
      "x": 102,
      "y": 213,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "motor_l",
      "type": "reg:dc-motor",
      "ref": "U3",
      "x": 149,
      "y": 173,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "motor_r",
      "type": "reg:dc-motor",
      "ref": "U4",
      "x": 149,
      "y": 189,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "us_1",
      "type": "reg:hc-sr04",
      "ref": "U5",
      "x": 102,
      "y": 94,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "sw_1",
      "type": "reg:slide-switch",
      "ref": "U6",
      "x": 102,
      "y": 76,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "led_eye_l",
      "type": "led",
      "ref": "D1",
      "x": 149,
      "y": 74,
      "rotation": 0,
      "props": {
        "color": "blue"
      },
      "mirror": false
    },
    {
      "id": "led_eye_r",
      "type": "led",
      "ref": "D2",
      "x": 149,
      "y": 36,
      "rotation": 0,
      "props": {
        "color": "blue"
      },
      "mirror": false
    },
    {
      "id": "led_mouth",
      "type": "led",
      "ref": "D3",
      "x": 149,
      "y": 55,
      "rotation": 0,
      "props": {
        "color": "red"
      },
      "mirror": false
    },
    {
      "id": "r_eye_l",
      "type": "resistor",
      "ref": "R1",
      "x": 102,
      "y": 42,
      "rotation": 0,
      "value": "300",
      "mirror": false
    },
    {
      "id": "r_eye_r",
      "type": "resistor",
      "ref": "R2",
      "x": 102,
      "y": 20,
      "rotation": 0,
      "value": "300",
      "mirror": false
    },
    {
      "id": "r_mouth",
      "type": "resistor",
      "ref": "R3",
      "x": 102,
      "y": 112,
      "rotation": 0,
      "value": "300",
      "mirror": false
    },
    {
      "id": "d_motor_l",
      "type": "diode",
      "ref": "D4",
      "x": 149,
      "y": 137,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_motor_r",
      "type": "diode",
      "ref": "D5",
      "x": 149,
      "y": 156,
      "rotation": 0,
      "mirror": false
    }
  ],
  "wires": [
    {
      "id": "bbs_w_0",
      "points": [
        {
          "x": 49,
          "y": 109
        },
        {
          "x": 24,
          "y": 109
        },
        {
          "x": 24,
          "y": 75
        },
        {
          "x": 96,
          "y": 75
        }
      ],
      "net": "N_D2"
    },
    {
      "id": "bbs_w_1",
      "points": [
        {
          "x": 49,
          "y": 111
        },
        {
          "x": 15,
          "y": 111
        },
        {
          "x": 15,
          "y": 240
        },
        {
          "x": 133,
          "y": 240
        },
        {
          "x": 133,
          "y": 207
        },
        {
          "x": 108,
          "y": 207
        }
      ],
      "net": "N_D3"
    },
    {
      "id": "bbs_w_2",
      "points": [
        {
          "x": 49,
          "y": 113
        },
        {
          "x": 24,
          "y": 113
        },
        {
          "x": 24,
          "y": 234
        },
        {
          "x": 127,
          "y": 234
        },
        {
          "x": 127,
          "y": 210
        },
        {
          "x": 108,
          "y": 210
        }
      ],
      "net": "N_D4"
    },
    {
      "id": "bbs_w_3",
      "points": [
        {
          "x": 49,
          "y": 115
        },
        {
          "x": 27,
          "y": 115
        },
        {
          "x": 27,
          "y": 228
        },
        {
          "x": 118,
          "y": 228
        },
        {
          "x": 118,
          "y": 219
        },
        {
          "x": 108,
          "y": 219
        }
      ],
      "net": "N_D5"
    },
    {
      "id": "bbs_w_4",
      "points": [
        {
          "x": 49,
          "y": 119
        },
        {
          "x": 30,
          "y": 119
        },
        {
          "x": 30,
          "y": 231
        },
        {
          "x": 121,
          "y": 231
        },
        {
          "x": 121,
          "y": 212
        },
        {
          "x": 108,
          "y": 212
        }
      ],
      "net": "N_D7"
    },
    {
      "id": "bbs_w_5",
      "points": [
        {
          "x": 49,
          "y": 121
        },
        {
          "x": 33,
          "y": 121
        },
        {
          "x": 33,
          "y": 237
        },
        {
          "x": 124,
          "y": 237
        },
        {
          "x": 124,
          "y": 214
        },
        {
          "x": 108,
          "y": 214
        }
      ],
      "net": "N_D8"
    },
    {
      "id": "bbs_w_6",
      "points": [
        {
          "x": 49,
          "y": 123
        },
        {
          "x": 36,
          "y": 123
        },
        {
          "x": 36,
          "y": 243
        },
        {
          "x": 130,
          "y": 243
        },
        {
          "x": 130,
          "y": 216
        },
        {
          "x": 108,
          "y": 216
        }
      ],
      "net": "N_D9"
    },
    {
      "id": "bbs_w_7",
      "points": [
        {
          "x": 49,
          "y": 125
        },
        {
          "x": 39,
          "y": 125
        },
        {
          "x": 39,
          "y": 95
        },
        {
          "x": 96,
          "y": 95
        }
      ],
      "net": "N_D10"
    },
    {
      "id": "bbs_w_8",
      "points": [
        {
          "x": 49,
          "y": 127
        },
        {
          "x": 18,
          "y": 127
        },
        {
          "x": 18,
          "y": 31
        },
        {
          "x": 118,
          "y": 31
        },
        {
          "x": 118,
          "y": 93
        },
        {
          "x": 108,
          "y": 93
        }
      ],
      "net": "N_D11"
    },
    {
      "id": "bbs_w_9",
      "points": [
        {
          "x": 49,
          "y": 129
        },
        {
          "x": 21,
          "y": 129
        },
        {
          "x": 21,
          "y": 34
        },
        {
          "x": 102,
          "y": 34
        },
        {
          "x": 102,
          "y": 39
        }
      ],
      "net": "N_D12"
    },
    {
      "id": "bbs_w_10",
      "points": [
        {
          "x": 49,
          "y": 131
        },
        {
          "x": 12,
          "y": 131
        },
        {
          "x": 12,
          "y": 12
        },
        {
          "x": 102,
          "y": 12
        },
        {
          "x": 102,
          "y": 17
        }
      ],
      "net": "N_D13"
    },
    {
      "id": "bbs_w_11",
      "points": [
        {
          "x": 61,
          "y": 105
        },
        {
          "x": 77,
          "y": 105
        },
        {
          "x": 77,
          "y": 104
        },
        {
          "x": 102,
          "y": 104
        },
        {
          "x": 102,
          "y": 109
        }
      ],
      "net": "N_A0"
    },
    {
      "id": "bbs_w_12",
      "points": [
        {
          "x": 61,
          "y": 117
        },
        {
          "x": 71,
          "y": 117
        },
        {
          "x": 71,
          "y": 215
        },
        {
          "x": 96,
          "y": 215
        }
      ],
      "net": "V5"
    },
    {
      "id": "bbs_w_13",
      "points": [
        {
          "x": 61,
          "y": 117
        },
        {
          "x": 71,
          "y": 117
        },
        {
          "x": 71,
          "y": 219
        },
        {
          "x": 96,
          "y": 219
        }
      ],
      "net": "V5"
    },
    {
      "id": "bbs_w_14",
      "points": [
        {
          "x": 61,
          "y": 117
        },
        {
          "x": 71,
          "y": 117
        },
        {
          "x": 71,
          "y": 93
        },
        {
          "x": 96,
          "y": 93
        }
      ],
      "net": "V5"
    },
    {
      "id": "bbs_w_15",
      "points": [
        {
          "x": 61,
          "y": 123
        },
        {
          "x": 74,
          "y": 123
        },
        {
          "x": 74,
          "y": 217
        },
        {
          "x": 96,
          "y": 217
        }
      ],
      "net": "0"
    },
    {
      "id": "bbs_w_16",
      "points": [
        {
          "x": 61,
          "y": 123
        },
        {
          "x": 121,
          "y": 123
        },
        {
          "x": 121,
          "y": 95
        },
        {
          "x": 108,
          "y": 95
        }
      ],
      "net": "0"
    },
    {
      "id": "bbs_w_17",
      "points": [
        {
          "x": 61,
          "y": 123
        },
        {
          "x": 74,
          "y": 123
        },
        {
          "x": 74,
          "y": 77
        },
        {
          "x": 96,
          "y": 77
        }
      ],
      "net": "0"
    },
    {
      "id": "bbs_w_18",
      "points": [
        {
          "x": 61,
          "y": 123
        },
        {
          "x": 149,
          "y": 123
        },
        {
          "x": 149,
          "y": 77
        }
      ],
      "net": "0"
    },
    {
      "id": "bbs_w_19",
      "points": [
        {
          "x": 61,
          "y": 123
        },
        {
          "x": 121,
          "y": 123
        },
        {
          "x": 121,
          "y": 44
        },
        {
          "x": 149,
          "y": 44
        },
        {
          "x": 149,
          "y": 39
        }
      ],
      "net": "0"
    },
    {
      "id": "bbs_w_20",
      "points": [
        {
          "x": 61,
          "y": 123
        },
        {
          "x": 121,
          "y": 123
        },
        {
          "x": 121,
          "y": 63
        },
        {
          "x": 149,
          "y": 63
        },
        {
          "x": 149,
          "y": 58
        }
      ],
      "net": "0"
    },
    {
      "id": "bbs_w_21",
      "points": [
        {
          "x": 96,
          "y": 207
        },
        {
          "x": 86,
          "y": 207
        },
        {
          "x": 86,
          "y": 173
        },
        {
          "x": 143,
          "y": 173
        }
      ],
      "net": "N6"
    },
    {
      "id": "bbs_w_22",
      "points": [
        {
          "x": 96,
          "y": 207
        },
        {
          "x": 86,
          "y": 207
        },
        {
          "x": 86,
          "y": 173
        },
        {
          "x": 118,
          "y": 173
        },
        {
          "x": 118,
          "y": 145
        },
        {
          "x": 149,
          "y": 145
        },
        {
          "x": 149,
          "y": 140
        }
      ],
      "net": "N6"
    },
    {
      "id": "bbs_w_23",
      "points": [
        {
          "x": 96,
          "y": 209
        },
        {
          "x": 80,
          "y": 209
        },
        {
          "x": 80,
          "y": 198
        },
        {
          "x": 165,
          "y": 198
        },
        {
          "x": 165,
          "y": 173
        },
        {
          "x": 155,
          "y": 173
        }
      ],
      "net": "N5"
    },
    {
      "id": "bbs_w_24",
      "points": [
        {
          "x": 96,
          "y": 209
        },
        {
          "x": 80,
          "y": 209
        },
        {
          "x": 80,
          "y": 126
        },
        {
          "x": 149,
          "y": 126
        },
        {
          "x": 149,
          "y": 134
        }
      ],
      "net": "N5"
    },
    {
      "id": "bbs_w_25",
      "points": [
        {
          "x": 96,
          "y": 211
        },
        {
          "x": 83,
          "y": 211
        },
        {
          "x": 83,
          "y": 189
        },
        {
          "x": 143,
          "y": 189
        }
      ],
      "net": "N8"
    },
    {
      "id": "bbs_w_26",
      "points": [
        {
          "x": 96,
          "y": 211
        },
        {
          "x": 83,
          "y": 211
        },
        {
          "x": 83,
          "y": 164
        },
        {
          "x": 149,
          "y": 164
        },
        {
          "x": 149,
          "y": 159
        }
      ],
      "net": "N8"
    },
    {
      "id": "bbs_w_27",
      "points": [
        {
          "x": 96,
          "y": 213
        },
        {
          "x": 77,
          "y": 213
        },
        {
          "x": 77,
          "y": 129
        },
        {
          "x": 168,
          "y": 129
        },
        {
          "x": 168,
          "y": 189
        },
        {
          "x": 155,
          "y": 189
        }
      ],
      "net": "N7"
    },
    {
      "id": "bbs_w_28",
      "points": [
        {
          "x": 96,
          "y": 213
        },
        {
          "x": 77,
          "y": 213
        },
        {
          "x": 77,
          "y": 129
        },
        {
          "x": 121,
          "y": 129
        },
        {
          "x": 121,
          "y": 148
        },
        {
          "x": 149,
          "y": 148
        },
        {
          "x": 149,
          "y": 153
        }
      ],
      "net": "N7"
    },
    {
      "id": "bbs_w_29",
      "points": [
        {
          "x": 102,
          "y": 45
        },
        {
          "x": 102,
          "y": 66
        },
        {
          "x": 149,
          "y": 66
        },
        {
          "x": 149,
          "y": 71
        }
      ],
      "net": "N2"
    },
    {
      "id": "bbs_w_30",
      "points": [
        {
          "x": 102,
          "y": 23
        },
        {
          "x": 102,
          "y": 28
        },
        {
          "x": 149,
          "y": 28
        },
        {
          "x": 149,
          "y": 33
        }
      ],
      "net": "N3"
    },
    {
      "id": "bbs_w_31",
      "points": [
        {
          "x": 102,
          "y": 115
        },
        {
          "x": 102,
          "y": 120
        },
        {
          "x": 124,
          "y": 120
        },
        {
          "x": 124,
          "y": 47
        },
        {
          "x": 149,
          "y": 47
        },
        {
          "x": 149,
          "y": 52
        }
      ],
      "net": "N4"
    }
  ],
  "junctions": [
    {
      "id": "j_61_117",
      "x": 61,
      "y": 117
    },
    {
      "id": "j_71_117",
      "x": 71,
      "y": 117
    },
    {
      "id": "j_71_215",
      "x": 71,
      "y": 215
    },
    {
      "id": "j_61_123",
      "x": 61,
      "y": 123
    },
    {
      "id": "j_74_123",
      "x": 74,
      "y": 123
    },
    {
      "id": "j_121_123",
      "x": 121,
      "y": 123
    },
    {
      "id": "j_121_95",
      "x": 121,
      "y": 95
    },
    {
      "id": "j_121_63",
      "x": 121,
      "y": 63
    },
    {
      "id": "j_86_207",
      "x": 86,
      "y": 207
    },
    {
      "id": "j_86_173",
      "x": 86,
      "y": 173
    },
    {
      "id": "j_118_173",
      "x": 118,
      "y": 173
    },
    {
      "id": "j_80_209",
      "x": 80,
      "y": 209
    },
    {
      "id": "j_80_198",
      "x": 80,
      "y": 198
    },
    {
      "id": "j_83_211",
      "x": 83,
      "y": 211
    },
    {
      "id": "j_83_189",
      "x": 83,
      "y": 189
    },
    {
      "id": "j_77_213",
      "x": 77,
      "y": 213
    },
    {
      "id": "j_77_129",
      "x": 77,
      "y": 129
    },
    {
      "id": "j_121_129",
      "x": 121,
      "y": 129
    }
  ],
  "netLabels": [
    {
      "id": "bbs_nl_0",
      "name": "N_D2",
      "x": 49,
      "y": 109,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_1",
      "name": "N_D3",
      "x": 49,
      "y": 111,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_2",
      "name": "N_D4",
      "x": 49,
      "y": 113,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_3",
      "name": "N_D5",
      "x": 49,
      "y": 115,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_4",
      "name": "N_D7",
      "x": 49,
      "y": 119,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_5",
      "name": "N_D8",
      "x": 49,
      "y": 121,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_6",
      "name": "N_D9",
      "x": 49,
      "y": 123,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_7",
      "name": "N_D10",
      "x": 49,
      "y": 125,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_8",
      "name": "N_D11",
      "x": 49,
      "y": 127,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_9",
      "name": "N_D12",
      "x": 49,
      "y": 129,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_10",
      "name": "N_D13",
      "x": 49,
      "y": 131,
      "owner": "arduino_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_11",
      "name": "N_A0",
      "x": 61,
      "y": 105,
      "owner": "arduino_1",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_12",
      "name": "V5",
      "x": 61,
      "y": 117,
      "owner": "arduino_1",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_13",
      "name": "GND",
      "x": 61,
      "y": 123,
      "owner": "arduino_1",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_14",
      "name": "N6",
      "x": 96,
      "y": 207,
      "owner": "drv_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_15",
      "name": "N5",
      "x": 96,
      "y": 209,
      "owner": "drv_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_16",
      "name": "N8",
      "x": 96,
      "y": 211,
      "owner": "drv_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_17",
      "name": "N7",
      "x": 96,
      "y": 213,
      "owner": "drv_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_18",
      "name": "N2",
      "x": 102,
      "y": 45,
      "owner": "r_eye_l",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_19",
      "name": "N3",
      "x": 102,
      "y": 23,
      "owner": "r_eye_r",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_20",
      "name": "N4",
      "x": 102,
      "y": 115,
      "owner": "r_mouth",
      "anchor": "end"
    }
  ],
  "probes": [],
  "directives": [],
  "breadboardSync": {
    "sourceHash": "22512:-1086485409",
    "symbolIds": [
      "arduino_1",
      "drv_1",
      "motor_l",
      "motor_r",
      "us_1",
      "sw_1",
      "led_eye_l",
      "led_eye_r",
      "led_mouth",
      "r_eye_l",
      "r_eye_r",
      "r_mouth",
      "d_motor_l",
      "d_motor_r"
    ],
    "wireIds": [
      "bbs_w_0",
      "bbs_w_1",
      "bbs_w_2",
      "bbs_w_3",
      "bbs_w_4",
      "bbs_w_5",
      "bbs_w_6",
      "bbs_w_7",
      "bbs_w_8",
      "bbs_w_9",
      "bbs_w_10",
      "bbs_w_11",
      "bbs_w_12",
      "bbs_w_13",
      "bbs_w_14",
      "bbs_w_15",
      "bbs_w_16",
      "bbs_w_17",
      "bbs_w_18",
      "bbs_w_19",
      "bbs_w_20",
      "bbs_w_21",
      "bbs_w_22",
      "bbs_w_23",
      "bbs_w_24",
      "bbs_w_25",
      "bbs_w_26",
      "bbs_w_27",
      "bbs_w_28",
      "bbs_w_29",
      "bbs_w_30",
      "bbs_w_31"
    ],
    "netLabelIds": [
      "bbs_nl_0",
      "bbs_nl_1",
      "bbs_nl_2",
      "bbs_nl_3",
      "bbs_nl_4",
      "bbs_nl_5",
      "bbs_nl_6",
      "bbs_nl_7",
      "bbs_nl_8",
      "bbs_nl_9",
      "bbs_nl_10",
      "bbs_nl_11",
      "bbs_nl_12",
      "bbs_nl_13",
      "bbs_nl_14",
      "bbs_nl_15",
      "bbs_nl_16",
      "bbs_nl_17",
      "bbs_nl_18",
      "bbs_nl_19",
      "bbs_nl_20"
    ]
  }
}